import { useAuth } from "../context/Contexts";

export default function Profile() {
    const { success } = useAuth();

    if (!success) {
        return <h1>Hozzáférés megtagadva! Kérlek jelentkezz be!</h1>;
    }

    return (
        <div className="container mt-5">
            <h1>Profil oldal</h1>
            <p>Itt láthatod a profilod adatait.</p>
        </div>
    );
}